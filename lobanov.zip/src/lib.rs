pub mod area_calc;
pub mod common;
pub mod integral_eq;
pub mod mathparse;
pub mod min_find;
pub mod problems;
pub mod spline;
pub mod app;